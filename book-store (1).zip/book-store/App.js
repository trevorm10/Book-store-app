import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, TextInput, Button, StyleSheet, ScrollView, FlatList } from 'react-native';
import { Picker } from '@react-native-picker/picker';

const Stack = createStackNavigator();

// Home Screen Component
function HomeScreen({ navigation }) {
  return (
    <View style={styles.homeContainer}>
      <Text style={styles.title}>BookNook</Text>
      <Text style={styles.subtitle}>Second-Hand Bookshop Manager</Text>
      
      <View style={styles.buttonContainer}>
        <Button
          title="Add New Book"
          onPress={() => navigation.navigate('BookEntry')}
          color="#6200ee"
        />
      </View>
    </View>
  );
}

// Book Entry Screen Component
function BookEntryScreen({ navigation }) {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState('Fiction');
  const [pages, setPages] = useState('');
  
  const genres = [
    'Fiction', 'Non-Fiction', 'Science', 
    'Biography', 'Romance', 'Mystery',
    'Fantasy', 'History', 'Children'
  ];

  const handleSubmit = () => {
    navigation.navigate('BookList', {
      newBook: { title, author, genre, pages }
    });
    // Reset form
    setTitle('');
    setAuthor('');
    setGenre('Fiction');
    setPages('');
  };

  return (
    <ScrollView contentContainerStyle={styles.entryContainer}>
      <Text style={styles.header}>Add New Book</Text>
      
      <Text style={styles.label}>Title</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="Book title"
      />
      
      <Text style={styles.label}>Author</Text>
      <TextInput
        style={styles.input}
        value={author}
        onChangeText={setAuthor}
        placeholder="Author name"
      />
      
      <Text style={styles.label}>Genre</Text>
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={genre}
          onValueChange={(itemValue) => setGenre(itemValue)}
        >
          {genres.map((genre, index) => (
            <Picker.Item key={index} label={genre} value={genre} />
          ))}
        </Picker>
      </View>
      
      <Text style={styles.label}>Number of Pages</Text>
      <TextInput
        style={styles.input}
        value={pages}
        onChangeText={setPages}
        placeholder="Page count"
        keyboardType="numeric"
      />
      
      <View style={styles.buttonContainer}>
        <Button
          title="Save Book"
          onPress={handleSubmit}
          color="#6200ee"
        />
      </View>
    </ScrollView>
  );
}

// Book List Screen Component
function BookListScreen({ navigation, route }) {
  const [books, setBooks] = React.useState([
    { id: '1', title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', genre: 'Fiction', pages: '218' },
    { id: '2', title: 'Sapiens', author: 'Yuval Noah Harari', genre: 'Non-Fiction', pages: '443' },
  ]);
  
  React.useEffect(() => {
    if (route.params?.newBook) {
      setBooks([...books, { ...route.params.newBook, id: String(books.length + 1) }]);
    }
  }, [route.params?.newBook]);

  return (
    <View style={styles.listContainer}>
      <Text style={styles.header}>Book Inventory</Text>
      
      <FlatList
        data={books}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <View style={styles.bookCard}>
            <Text style={styles.bookTitle}>{item.title}</Text>
            <Text>Author: {item.author}</Text>
            <Text>Genre: {item.genre}</Text>
            <Text>Pages: {item.pages}</Text>
          </View>
        )}
        contentContainerStyle={{ paddingBottom: 20 }}
      />
      
      <View style={styles.buttonGroup}>
        <View style={styles.buttonWrapper}>
          <Button
            title="Add Another Book"
            onPress={() => navigation.navigate('BookEntry')}
            color="#6200ee"
          />
        </View>
        <View style={styles.buttonWrapper}>
          <Button
            title="Back to Home"
            onPress={() => navigation.navigate('Home')}
            color="#999"
          />
        </View>
      </View>
    </View>
  );
}

// Main App Component
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'BookNook' }} />
        <Stack.Screen name="BookEntry" component={BookEntryScreen} options={{ title: 'Add Book' }} />
        <Stack.Screen name="BookList" component={BookListScreen} options={{ title: 'Book Inventory' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  // Home Screen
  homeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5'
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333'
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 40,
    color: '#666'
  },
  
  // Book Entry
  entryContainer: {
    padding: 20,
    backgroundColor: '#fff'
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center'
  },
  label: {
    fontSize: 16,
    marginTop: 10,
    marginBottom: 5
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    marginBottom: 15,
    overflow: 'hidden'
  },
  
  // Book List
  listContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5'
  },
  bookCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    borderLeftWidth: 4,
    borderLeftColor: '#6200ee'
  },
  bookTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5
  },
  
  // Shared
  buttonContainer: {
    marginTop: 20,
    borderRadius: 5,
    overflow: 'hidden'
  },
  buttonGroup: {
    marginTop: 10,
    marginBottom: 20
  },
  buttonWrapper: {
    marginVertical: 5,
    borderRadius: 5,
    overflow: 'hidden'
  }
});
